<?php

class ApiImport_ResponseAdapter_RecordAdapterException extends Exception
{

}