<div id="page-hierarchy">
<?php echo simple_pages_display_hierarchy(0); ?>
</div>