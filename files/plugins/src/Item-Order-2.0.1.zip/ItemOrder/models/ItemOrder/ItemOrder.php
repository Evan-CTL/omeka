<?php
class ItemOrder_ItemOrder extends Omeka_Record_AbstractRecord
{
    public $collection_id;
    public $item_id;
    public $order;
}
